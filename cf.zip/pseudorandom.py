seed = 123456789

a= 3110521015
c= 12345
m = pow(2,32)

def LCG():
	global seed
	seed = (a*seed + c) %m
	return seed

print "how many numbers you want to generate:"
n = int(raw_input())
i=0
while i<n:
	print (LCG())
	i=i+1

