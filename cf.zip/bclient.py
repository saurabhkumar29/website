import socket,sys

print ""
print "Enter multiplicand"
num1 = raw_input()

print "Enter multiplier"
num2 = raw_input()

print "Enter length of the multiplicand"
num3 = raw_input()

print "Enter length of the multiplier"
num4 = raw_input()

numbers = num1 + "," + num2 + "," + num3 +"," + num4

clientsocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
clientsocket.connect(("localhost",5000))

clientsocket.send(numbers)

print ""
clientsocket.close()
