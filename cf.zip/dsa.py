import random

def numberofbits(n):
	return (len(bin(p))-2)

def brutualprime(n):
	isprime= True
	i=2
	while (i<=n/2):
		if n%i ==0:
			isprime=False
			return isprime
		i=i+1
	return isprime

def millerrabinprime(n):
	k=1000
	i=0
	isprobablyprime=True
	while i<k:
		randomcheck= random.randint(2,(n-2))
		if (n%randomcheck==0):
			isprobablyprime=False
			return isprobablyprime
		i=i+1

	return isprobablyprime

print ("Enter the tuple parameter values of (p,q,g)")
print "Enter the value of p:"
p= long(raw_input())
print "Enter the value of q:"
q= long(raw_input())
print "Enter the value of g:"
g= long(raw_input())

print "According to brute force primality test q is :"
print (brutualprime(q))

print "According to millerrabin primality test q is:"
print (millerrabinprime(q))

print "Is q of 160 bits?"
numberofbitsofQ = numberofbits(q)
if numberofbitsofQ==160:
	print "True"
else:
	print "False"

print "Does q divide p-1?"
if (((p-1) % q) == 0):
	print "True"
else:
	print "False"

print "Is number of bits of p between 512 and 1024"
numberofbitsofP = numberofbits(p)
if (numberofbitsofP >=512) and (numberofbitsofP <=1024):
	print "True"
else:
	print "False"

print "Is g of the form (h^((p-1)/q) mod p) where h=2"
complexelement= ((p-1)/q)
h=2
if (g == ((pow(h,complexelement)) % p)):
	print "True"
else:
	print "False"
