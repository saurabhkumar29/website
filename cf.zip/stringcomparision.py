def checker(text1,text2):
	match =0
	smallerlength = 0

	if(len(text1) <= len(text2)):
		smallerlength = len(text1)
	else:
		smallerlength = len(text2)

	i=0

	while i < smallerlength:
		if text1[i] == text2[i]:
			match = match + 1
		i=i+1
	
	similaritypercentage = (match / smallerlength) * 100
	return similaritypercentage

if __name__ == "__main__":
	print ""