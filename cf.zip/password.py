import base64

def Encryption(key,message):
	ciphertextcharacters = []
	for i in range(len(message)):
		keyforcurrentcharacter = key[(i% len(key))]

		currentciphertextcharacter = chr(ord(message[i]) + ord(keyforcurrentcharacter) % 256)

		ciphertextcharacters.append(currentciphertextcharacter)
	ciphertext = "".join(ciphertextcharacters)
	return ciphertext


def Decryption(key,message):
	decryptedtextcharacters = []
	for i in range(len(ciphertext)):
		keyforcurrentcharacter = key[(i% len(key))]

		currentdecryptedtextcharacter = chr((256 + ord(ciphertext[i]) - ord(keyforcurrentcharacter)) % 256)

		decryptedtextcharacters.append(currentdecryptedtextcharacter)
	decryptedtext = "".join(decryptedtextcharacters)
	return decryptedtext

def Illusion(text1,text2,flag):
	if flag is True:
		output = Encryption(text1,text2)
		return output
	else:
		output = Decryption(text1,text2)
		return output

print "Enter the key"
text1 = raw_input()

print "Enter the message"
text2 = raw_input()

print "Cipher text for the message is"
ciphertext = Illusion(text1, text2, True)
abcd = base64.urlsafe_b64encode(ciphertext)
print(ciphertext)

print "The decrypted text is"
decryptedtext = Illusion(text1,text2,False)
print (decryptedtext)
