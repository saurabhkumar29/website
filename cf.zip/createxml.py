import os
import random
import sys

name = raw_input("Enter the name of the file: ")+".xml"
file = open(name, 'w')
file.write("<Numbers>\n")
for i in range(10):
    file.write("\t<integer num = \""+str(random.randint(0,800))+"\" > </integer>\n")
file.write("</Numbers>\n")
file.close()
temp = input(name+"file is written, to see contents press 1:")
if(temp==1):
    os.system("cat "+name)
    tmp=input("\n press 2 to start quicksort program: ")
    if(tmp==2):
        os.system("python quicksort.py "+name)
