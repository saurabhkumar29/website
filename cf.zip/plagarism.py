from flask import Flask
from flask import request
from flask import render_template
import stringcomparision

app = Flask(__name__)

@app.route('/')
def my_form():
	return render_template("my-form.html")

@app.route('/', methods = ['POST'])
def my_form_post():

	text1= request.form['text1']
	text2= request.form['text2']

	plagarismpercent= stringcomparision.checker(text1,text2)

	if plagarismpercent >50:
		return "<h1>Plagarism Detected</h1>"
	else:
		return "<h1>Plagarism not detected </h1>"

if __name__ == '__main__':
	app.run()
