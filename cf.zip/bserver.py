import sys,socket,booths

serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serversocket.bind(("", 5000))
serversocket.listen(5)

clientsocket , address = serversocket.accept()
receivednumbersinkbps = clientsocket.recv(1024)
receivednumbers = ""

while receivednumbersinkbps:
	receivednumbers = receivednumbersinkbps + receivednumbers
	receivednumbersinkbps = ""
	receivednumbersinkbps = clientsocket.recv(1024)

numberlist = receivednumbers.split(',')

multiplicand = int(numberlist[0])
multiplier = int(numberlist[1])
multiplicandlength = int(numberlist[2])
multiplierlength = int(numberlist[3])

product = booths.booth(multiplicand, multiplier, multiplicandlength, multiplierlength)

print ""
print "The product of " + str(multiplicand) + " and " + str(multiplier) + " is " + str(product)
print ""

clientsocket.close()
serversocket.close()
