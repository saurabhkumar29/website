from bitstring import BitArray

def booth(m,r,x,y):
	totallength= x+y+1
	mA= BitArray(int =m, length = totallength)
	A = mA << (y+1)
	S = BitArray(int=-m, length = totallength) << (y+1)
	P = BitArray(int=r, length=y)
	P.prepend(BitArray(int=0,length=x))
	P=P<<1
	print "Initial Values"
	print "A = ", A.bin
	print "S = ", S.bin
	print "P = ", P.bin

	for i in range(1,y+1):
		if P[-2:] == '0b01':
			P = BitArray(int = P.int + A.int, length = totallength)
			print "P + A:", P.bin
		elif P[-2:] == '0b10' :
			P = BitArray(int = P.int + S.int, length = totallength)
			print "P + B:", P.bin
		P = arithmatic_shift_right(P,1)
		print "P >> 1:", P.bin
	P = arithmatic_shift_right(P,1)
	print "P >> 1:", P.bin
	return P.int

def arithmatic_shift_right(x,amt):
	l=x.len
	x= BitArray(int= (x.int >> amt), length = l)
	return x

if __name__ == "__main__":
	print ""
