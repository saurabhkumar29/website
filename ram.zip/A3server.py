import socket,sys,booths


serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serversocket.bind(("",5000))
serversocket.listen(5)

clientsocket, address = serversocket.accept()
reci_Num_InKbs = clientsocket.recv(1024)
reci_Num = ""

while reci_Num_InKbs :
    reci_Num = reci_Num + reci_Num_InKbs
    reci_Num_InKbs = ""
    reci_Num_InKbs = clientsocket.recv(1024)

numberList = reci_Num.split(',')

multiplicand = int(numberList[0])
multiplier = int(numberList[1])
multiplicandLength = int(numberList[2])
multiplierLength = int(numberList[3])


product = booths.booth(multiplicand,multiplier,multiplicandLength,multiplierLength)

print("")
print("The product of " + str(multiplicand) + " and " + str(multiplier) + " is = " + str(product))
print("")
clientsocket.close()
serversocket.close()
