import base64

def Encryption(key,message) :
    cipherTextCharacters = []
    for i in range(len(message)) :
        key_enc = key[i % len(key)]
        currentCipher = chr(ord(message[i]) + ord(key_enc) % 256)
        cipherTextCharacters.append(currentCipher)
    	cipherText = "".join(cipherTextCharacters) 
    return cipherText

def Decryption(key,cipherText) :
    decryptedTextCharacters = []

    for i in range(len(cipherText)) :
        keyForCurrentCharacter = key[i % len(key)]
        currentDecryptedTextCharacter = chr((256 + ord(cipherText[i]) - ord(keyForCurrentCharacter)) % 256)
        decryptedTextCharacters.append(currentDecryptedTextCharacter)
    	decryptedText = "".join(decryptedTextCharacters)
    return decryptedText  

print("Enter your password (i.e. key) - ")
key = raw_input()

print("Enter your message to be encrypted - ")
message = raw_input()

print("This is the cipher text generated - which can totally not be cracked ;) - ")
cipherText = Encryption(key,message)
gibberish = base64.urlsafe_b64encode(cipherText) 
print(gibberish)

print("This is the decrypted message using your password which is supposed to match your original message - ")
decryptedText = Decryption(key,cipherText)
print(decryptedText)



